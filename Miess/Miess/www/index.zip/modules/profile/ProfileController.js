/**
 * The profile controller maintaince the user currently using the system
 * and the agenda's belonging to the user.
 *  
 * 
 */


