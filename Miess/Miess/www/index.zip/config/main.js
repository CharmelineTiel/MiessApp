/**
 * global declaration used in the system
 * 
 */
var config = {
	/**
	 * the server used to connect to.
	 * 
	 * @type string
	 */
	'server' : 'http://www.miessagenda.localhost/agenda/api/'
};

