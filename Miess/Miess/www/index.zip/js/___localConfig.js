/**
 * 
 * @type String the url to connect to
 * must and with /
 */
 //serverUrl = 'http://www.miessagenda.nl/api/index.php/';
// var isIos = true;


 var serverUrl = 'http://www.miessagenda.nl/api/index.php/';
 var isIos = false;

